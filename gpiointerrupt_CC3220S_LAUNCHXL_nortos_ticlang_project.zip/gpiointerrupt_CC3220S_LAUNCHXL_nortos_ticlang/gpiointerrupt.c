#include <ti/drivers/UART2.h>
#include <ti/drivers/I2C.h>
#include <ti/drivers/Timer.h>
#include <ti/drivers/GPIO.h>
#include "ti_drivers_config.h"

#define DISPLAY(x) UART2_write(uart, &output, x, &bytesRead);

// UART Global Variables
size_t bytesRead;
char output[64];
int bytesToSend;
UART2_Handle uart;

// I2C Global Variables
static const struct {
    uint8_t address;
    uint8_t resultReg;
    char *id;
} sensors[3] = {
    { 0x48, 0x0000, "11X" },
    { 0x49, 0x0000, "116" },
    { 0x41, 0x0001, "006" }
};
uint8_t txBuffer[1];
uint8_t rxBuffer[2];
I2C_Transaction i2cTransaction;
I2C_Handle i2c;

// Timer Global Variables
Timer_Handle timer0;
volatile unsigned char TimerFlag = 0;

// GPIO Constants for LED
#define LED_PIN         CONFIG_GPIO_LED_0

// Temperature Control Variables
int16_t temperatureSetpoint = 25; // Initial set-point temperature
int16_t roomTemperature;
bool heatOn = false;
volatile uint32_t secondsCounter = 0;
char uartOutputBuffer[64];

// Function Prototypes
void initUART(void);
void initI2C(void);
int16_t readTemp(void);
void initTimer(void);
void updateLED(void);
void reportToServer(void);
void buttonInterruptHandler(uint_least8_t index);
void timerCallback(Timer_Handle myHandle, int_fast16_t status);
void *mainThread(void);


// Initiate UART
void initUART(void)
{
    UART2_Params uartParams;


    // Configure the driver
    UART2_Params_init(&uartParams);
    uartParams.writeMode = UART2_Mode_BLOCKING;
    uartParams.readMode = UART2_Mode_BLOCKING;
    uartParams.readReturnMode = UART2_ReadReturnMode_FULL;
    uartParams.baudRate = 115200;


    // Open the driver
    uart = UART2_open(CONFIG_UART2_0, &uartParams);


    if (uart == NULL) {
    /* UART_open() failed */
    while (1);
    }
}


// Make sure you call initUART() before calling this function.
// Initiate I2C
void initI2C(void)
{
    int8_t i, found;
    I2C_Params i2cParams;
    DISPLAY(snprintf(output, 64, "Initializing I2C Driver - "))


    // Init the driver
    I2C_init();


    // Configure the driver
    I2C_Params_init(&i2cParams);
    i2cParams.bitRate = I2C_400kHz;


    // Open the driver
    i2c = I2C_open(CONFIG_I2C_0, &i2cParams);
    if (i2c == NULL)
    {
            DISPLAY(snprintf(output, 64, "Failed\n\r"))
                while (1);
    }

    DISPLAY(snprintf(output, 32, "Passed\n\r"))


    // Boards were shipped with different sensors.
    // Welcome to the world of embedded systems.
    // Try to determine which sensor we have.
    // Scan through the possible sensor addresses

    /* Common I2C transaction setup */
    i2cTransaction.writeBuf = txBuffer;
    i2cTransaction.writeCount = 1;
    i2cTransaction.readBuf = rxBuffer;
    i2cTransaction.readCount = 0;


    found = false;
    for (i=0; i<3; ++i)
    {
        i2cTransaction.targetAddress = sensors[i].address;
        txBuffer[0] = sensors[i].resultReg;


        DISPLAY(snprintf(output, 64, "Is this %s? ", sensors[i].id))
        if (I2C_transfer(i2c, &i2cTransaction))
        {
            DISPLAY(snprintf(output, 64, "Found\n\r"))
            found = true;
            break;
        }
        DISPLAY(snprintf(output, 64, "No\n\r"))
     }
    if(found)
    {
        DISPLAY(snprintf(output, 64, "Detected TMP%s I2C address: %x\n\r", sensors[i].id, i2cTransaction.targetAddress))
    }
    else
    {
        DISPLAY(snprintf(output, 64, "Temperature sensor not found, contact professor\n\r"))
    }
}


// Read current temperature
int16_t readTemp(void)
{
    int j;
    int16_t temperature = 0;

    i2cTransaction.readCount = 2;
    if (I2C_transfer(i2c, &i2cTransaction))
    {
        /*
        * Extract degrees C from the received data;
        * see TMP sensor datasheet
        */
        temperature = (rxBuffer[0] << 8) | (rxBuffer[1]);
        temperature *= 0.0078125;
        /*
        * If the MSB is set '1', then we have a 2's complement
        * negative value which needs to be sign extended
        */
        if (rxBuffer[0] & 0x80)
        {
            temperature |= 0xF000;
        }

        DISPLAY(snprintf(output, 64, "Raw Temperature Reading: %d\n\r", temperature));
    }
    else
    {
        DISPLAY(snprintf(output, 64, "Error reading temperature sensor (%d)\n\r",i2cTransaction.status))
        DISPLAY(snprintf(output, 64, "Please power cycle your board by unplugging USB and plugging back in.\n\r"))
    }



    return temperature;
}

// Initiate Timer
void initTimer(void)
{
    Timer_Params params;


    // Init the driver
    Timer_init();


    // Configure the driver
    Timer_Params_init(&params);
    params.period = 1000;
    params.periodUnits = Timer_PERIOD_US;
    params.timerMode = Timer_CONTINUOUS_CALLBACK;
    params.timerCallback = timerCallback;



    // Open the driver
    timer0 = Timer_open(CONFIG_TIMER_0, &params);
    if (timer0 == NULL) {
        /* Failed to initialized timer */
        while (1) {}
    }
    if (Timer_start(timer0) == Timer_STATUS_ERROR) {
        /* Failed to start timer */
        while (1) {}
    }
}


// if roomTemp>25, then LED off, otherwise ON
void updateLED() {
    if (roomTemperature > temperatureSetpoint) {
        // Turn off the LED (heat off)
        GPIO_write(LED_PIN, CONFIG_GPIO_LED_OFF);
        heatOn = false;
    } else {
        // Turn on the LED (heat on)
        GPIO_write(LED_PIN, CONFIG_GPIO_LED_ON);
        heatOn = true;
    }
}

// send message to Terminal
void reportToServer()
{

    int writtenBytes;

    writtenBytes = snprintf(output, 64, "<%02d,%02d,%d,%04d>",
                            roomTemperature, temperatureSetpoint, heatOn, secondsCounter);

    if (UART2_write(uart, &output, writtenBytes, &bytesRead) != UART2_STATUS_SUCCESS) {
        // Handle UART write error
        DISPLAY(snprintf(output, 64, "UART write error\n\r"));
    }
    usleep(1000);
}

// when clicking left button, temperature set point ++; right button, temperate set point --
void buttonInterruptHandler(uint_least8_t index)
{
    static uint32_t lastButtonPressTime = 0;
    uint32_t currentTime = Timer_getCount(timer0);

    // Check if 200ms have passed since the last button press
    if (currentTime - lastButtonPressTime >= 200) {
        if (index == CONFIG_GPIO_BUTTON_0) {
            // Increase temperature set-point
            temperatureSetpoint++;
        } else if (index == CONFIG_GPIO_BUTTON_1) {
            // Decrease temperature set-point
            temperatureSetpoint--;
        }

        // Update the last button press time
        lastButtonPressTime = currentTime;
    }
}

// Making everything routine
void timerCallback(Timer_Handle myHandle, int_fast16_t status)
{
    static uint32_t lastButtonPressTime = 0;
    static uint32_t lastTemperatureReadTime = 0;

    // Check buttons every 200ms
    if (Timer_getCount(myHandle) - lastButtonPressTime >= 200) {
        if (GPIO_read(CONFIG_GPIO_BUTTON_0) == 0) {
            // Increase temperature set-point
            temperatureSetpoint++;
        } else if (GPIO_read(CONFIG_GPIO_BUTTON_1) == 0) {
            // Decrease temperature set-point
            temperatureSetpoint--;
        }

        // Update the last button press time
        lastButtonPressTime = Timer_getCount(myHandle);
    }

    // Read temperature every 500ms
    if (Timer_getCount(myHandle) - lastTemperatureReadTime >= 500
            ) {
        roomTemperature = readTemp();
        updateLED();
        lastTemperatureReadTime = Timer_getCount(myHandle);
    }

    // Report to the server every second
    reportToServer();

    // Increment seconds counter
    secondsCounter++;
}

void *mainThread(void)
{

    /* Call driver init functions */
    GPIO_init();

    /* Configure the LED pin */
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);


    // Initialize system
    Board_init();
    initUART();
    initI2C();
    int abc = readTemp();
    initTimer();

    // Initialize GPIOs for buttons and LED
    GPIO_init();
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_INPUT | GPIO_CFG_IN_INT_FALLING);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_1, GPIO_CFG_INPUT | GPIO_CFG_IN_INT_FALLING);
    GPIO_setConfig(LED_PIN, GPIO_CFG_OUTPUT);

    // Setup button interrupts
    GPIO_setCallback(CONFIG_GPIO_BUTTON_0, buttonInterruptHandler);
    GPIO_setCallback(CONFIG_GPIO_BUTTON_1, buttonInterruptHandler);
    GPIO_enableInt(CONFIG_GPIO_BUTTON_0);
    GPIO_enableInt(CONFIG_GPIO_BUTTON_1);

    // Start Timer
    if (Timer_start(timer0) == Timer_STATUS_ERROR) {
        /* Failed to start timer */
        while (1) {}
    }

    // Main loop
    while (1)
    {
        sleep(1);
    }
}






